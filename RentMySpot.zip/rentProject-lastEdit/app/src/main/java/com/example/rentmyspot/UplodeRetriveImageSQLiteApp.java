package com.example.rentmyspot;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
//
public class UplodeRetriveImageSQLiteApp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_uplode_retrive_image_sqlite_app);
    }
}